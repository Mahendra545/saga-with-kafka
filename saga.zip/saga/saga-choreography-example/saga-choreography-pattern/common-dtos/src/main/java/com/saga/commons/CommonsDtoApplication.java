package com.saga.commons;

public class CommonsDtoApplication {

    public static void main(String[] args) {

    }
}
